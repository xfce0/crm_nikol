#!/bin/bash

echo "🔍 Проверка версии кода на сервере"
echo "=================================="

# Проверяем коммиты
echo "📝 Последние 5 коммитов:"
git log --oneline -5

echo ""
echo "🔧 Проверяем файл avito_polling_service.py:"
grep -n "get_chat_messages_no_cache\|get_chat_messages(" app/services/avito_polling_service.py || echo "❌ Файл не найден или метод не найден"

echo ""
echo "🔧 Проверяем файл avito_service.py:"
grep -n "use_cache.*bool\|get_chat_messages_no_cache" app/services/avito_service.py || echo "❌ Параметры не найдены"

echo ""
echo "📊 Статус PM2:"
pm2 list | grep bot-business-card || echo "❌ PM2 процесс не найден"